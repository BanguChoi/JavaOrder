package com.javaOrder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
